package Day4;
//wap to print welcome message 10 time using do while 

// in do while program block will execute at least once even if condition is false
//exit control loop
//menu driven application
public class dowhileExample {

	public static void main(String[] args) {
		int i=1;
		do
		{
			System.out.println("welcome"+i);
			i++;
		}while(i<=10);
		System.out.println(i);
       
	}

}
