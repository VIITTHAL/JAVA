package Day4;
//nested loop
//wap to print table of given number 
//wap to print table from 2 to 5
public class pattern1 {

	public static void main(String[] args) {
		
		for(int n=2;n<=5;n++)
		{
		for(int i=1;i<=10;i++)		
			System.out.print ("  "+ n*i);
		
		System.out.println();
		}
		

	}

}
