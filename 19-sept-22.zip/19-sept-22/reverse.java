package Day4;
//wap to print reverse of a given number
public class reverse {

	public static void main(String[] args) {

    int n;
    
    for(n=123456;n!=0;)
    {
    	System.out.print(n%10); //65
        n= n/10;       
	}
    
    
    
  

	}

}
