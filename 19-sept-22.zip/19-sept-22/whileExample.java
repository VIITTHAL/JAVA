package Day4;
//wap to print welcome message 10 times
//entry control loop 
public class whileExample {

	public static void main(String[] args) {
		
		int i=19;
		while(i<=10)
		{
			System.out.println("welcomwe");
			 i=i+2;
			
		}

		//for(;;)//infinite loop
		
		//while(true)	{} inifinite loop 
	}

}
