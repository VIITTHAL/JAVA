package Day4;

/*
 *  wap to ask password from user and check if its == 12345 
 *  if yes then access allowed
 *  else retry max 3 times 
 *  after 3 times print card is block
 * 
 */
//for loop 
import java.util.*;

public class Passwordcheck2 {

	public static void main(String[] args) {
    Scanner s= new Scanner(System.in);
    int pass;
    int i=1;
  
	//for( i=1;i<=3;i++)
	while(i<=3)
    {
      System.out.println("enter password");
      pass= s.nextInt();
    
       if(pass==12345)
        {
    	System.out.println("access allowed");
    	break;
       }  	
       i++;
	}
	  if( i==4)   System.out.println("card is blocked");
  }

}
