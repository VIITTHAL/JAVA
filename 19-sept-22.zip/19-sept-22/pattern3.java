package Day4;
/*
 *     1  
 *     12 
 *     123
 *     1234
 *     12345
 */
public class  pattern3 {

	public static void main(String[] args) {
		
		for(int i=1;i<=5;i++)//row  1   2
		{
		  for(int j=1;j<=i;j++)//column  1
		  {
		  System.out.print(i);
		  //System.out.print(j);
		  }
		  System.out.println();
		  }
	}

}
